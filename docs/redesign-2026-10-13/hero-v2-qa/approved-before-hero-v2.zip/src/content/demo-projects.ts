import type { Locale } from './index';
import type { ModuleSlug } from './portfolio';

export const demoProjectNames: Record<ModuleSlug, string> = {
  intake: 'Cherryli', budget: 'Budget', approval: 'Aprobery', erp: 'ERP', visibility: 'Steer',
};

export function demoProjects(locale: Locale) {
  const s = (ru: string, en: string, ro: string) => ({ ru, en, ro })[locale];
  return {
    eyebrow: s('Демо-проекты Optimix', 'Optimix demo projects', 'Proiecte demo Optimix'),
    title: s('Один процесс. Своя система для каждого шага.', 'One process. A system for every step.', 'Un proces. Un sistem pentru fiecare pas.'),
    intro: s('Посмотрите, как выглядит автоматизация в работе — от первой заявки до общей картины бизнеса.', 'See automation at work — from the first request to a shared view of your business.', 'Vezi automatizarea în lucru — de la prima cerere la imaginea de ansamblu a afacerii.'),
    demo: s('Демо-сценарий', 'Demo scenario', 'Scenariu demo'),
    open: s('Разобрать проект', 'Explore the project', 'Explorează proiectul'),
    tryDemo: s('Пройти сценарий', 'Try the workflow', 'Încearcă fluxul'),
    deck: {
      cover: s('Демо-проекты','Demo projects','Proiecte demo'),
      reveal: s('Наведите, чтобы раскрыть','Hover to reveal','Treci cu cursorul pentru a dezvălui'),
      hint: s('Наведите, чтобы раскрыть · Нажмите, чтобы открыть · Ещё раз — перевернуть','Hover to explore · Click to open · Click again to flip','Treci cu cursorul · Apasă pentru a deschide · Apasă din nou pentru a întoarce'),
      touchHint: s('Выберите карту · Нажмите ещё раз, чтобы перевернуть','Choose a card · Tap again to flip','Alege o carte · Apasă din nou pentru a întoarce'),
      open: s('Открыть карту','Open card','Deschide cartea'),
      flip: s('Перевернуть карту','Flip card','Întoarce cartea'),
      close: s('Закрыть карту','Close card','Închide cartea'),
      back: s('Назад','Back','Înapoi'),
      how: s('Как это работает','How it works','Cum funcționează'),
      choose: s('Выберите демо-проект','Choose a demo project','Alege un proiect demo'),
    },
    projects: [
      {slug:'intake' as const, icon:'file-text', category:s('Заявки и документы','Requests and documents','Cereri și documente'), title:s('Любой запрос начинается с порядка.','Every request starts with clarity.','Orice cerere începe cu ordine.'), description:s('Cherryli собирает заявку, документы и участников в одной записи. Команда сразу видит, что нужно проверить и кому передать задачу.','Cherryli brings the request, documents and participants into one record. The team sees what needs checking and who takes over.','Cherryli reunește cererea, documentele și participanții într-o singură înregistrare. Echipa vede ce trebuie verificat și cui îi revine sarcina.'), tags:[s('Единая заявка','One request','Cerere unică'),s('Документы','Documents','Documente'),s('Ответственный','Owner','Responsabil')]},
      {slug:'budget' as const, icon:'database', category:s('Бюджет и планирование','Budget and planning','Buget și planificare'), title:s('Бюджет понятен до принятия решения.','Understand the budget before deciding.','Buget clar înainte de decizie.'), description:s('Budget сопоставляет сумму заявки с доступным остатком. Если не хватает данных или лимита, вопрос возвращается владельцу бюджета.','Budget compares the request amount with the available balance. Missing data or an exceeded limit goes back to the budget owner.','Budget compară suma cererii cu soldul disponibil. Datele lipsă sau depășirea limitei revin responsabilului de buget.'), tags:[s('Лимиты','Limits','Limite'),s('Проверка правил','Rule checks','Verificarea regulilor'),s('План и факт','Plan and actuals','Plan și realizat')]},
      {slug:'approval' as const, icon:'check-square', category:s('Согласования и решения','Approvals and decisions','Aprobări și decizii'), title:s('Решения движутся, а не теряются.','Decisions move forward, with a record.','Deciziile avansează și se păstrează.'), description:s('Aprobery показывает очередь согласований, контекст и следующий шаг. Решение сотрудника остаётся в истории вместе с документами.','Aprobery shows the approval queue, context and next step. Each decision stays in the history alongside its documents.','Aprobery arată coada de aprobări, contextul și pasul următor. Decizia rămâne în istoric alături de documente.'), tags:[s('Маршруты','Workflows','Trasee'),s('Роли','Roles','Roluri'),s('История решений','Decision history','Istoricul deciziilor')]},
      {slug:'erp' as const, icon:'gear', category:s('ERP и операции','ERP and operations','ERP și operațiuni'), title:s('Подтверждённые данные — дальше в ERP.','Approved data moves on to ERP.','Datele aprobate ajung în ERP.'), description:s('ERP-сценарий показывает передачу согласованной заявки в заказ. Поля сопоставлены, результат проверен, номер заказа связан с исходной записью.','The ERP scenario turns an approved request into an order. Fields are mapped, the response is checked and the order reference stays linked to the request.','Scenariul ERP transformă cererea aprobată în comandă. Câmpurile sunt mapate, răspunsul verificat și numărul comenzii legat de cerere.'), tags:[s('Связанные записи','Linked records','Înregistrări conectate'),s('Передача данных','Data transfer','Transfer de date'),s('Контроль ошибок','Error checks','Controlul erorilor')]},
      {slug:'visibility' as const, icon:'chart-bar', category:s('Аналитика и контроль','Analytics and oversight','Analiză și control'), title:s('Весь маршрут виден с одного экрана.','The whole workflow on one screen.','Întregul traseu pe un singur ecran.'), description:s('Steer объединяет статусы, ответственных и историю событий. Видно, где процесс находится сейчас и какое действие должно быть следующим.','Steer brings together statuses, owners and event history. See where the process stands and what needs to happen next.','Steer reunește stările, responsabilii și istoricul evenimentelor. Vezi unde se află procesul și care este acțiunea următoare.'), tags:[s('Статусы','Statuses','Stări'),s('События','Events','Evenimente'),s('Следующий шаг','Next step','Pasul următor')]},
    ],
    ui: {
      request:s('Заявка на оборудование','Equipment request','Cerere de echipamente'),
      newRequest:s('Новая заявка','New request','Cerere nouă'),
      department:s('Подразделение','Department','Departament'), operations:s('Операционный отдел','Operations team','Echipa operațională'),
      owner:s('Ответственный','Owner','Responsabil'), team:s('Команда закупок','Procurement team','Echipa de achiziții'),
      files:s('Документы приложены','Documents attached','Documente atașate'), ready:s('Готова к проверке','Ready for review','Gata de verificare'),
      budget:s('Бюджет подразделения','Department budget','Bugetul departamentului'), available:s('Доступно до заявки','Available before request','Disponibil înainte de cerere'), amount:s('Сумма заявки','Request amount','Suma cererii'), balance:s('Остаток после заявки','Balance after request','Soldul după cerere'), passed:s('В пределах лимита','Within the limit','În limita bugetului'),
      approval:s('Маршрут согласования','Approval workflow','Traseul de aprobare'), finance:s('Финансы','Finance','Finanțe'), approved:s('Согласовано','Approved','Aprobat'), manager:s('Руководитель','Manager','Manager'), pending:s('Ожидает решения','Awaiting a decision','Așteaptă decizia'), purchasing:s('Закупки','Procurement','Achiziții'), next:s('Следующий этап','Next stage','Etapa următoare'),
      transfer:s('Передача в ERP','Transfer to ERP','Transfer în ERP'), source:s('Исходная запись','Source record','Înregistrare sursă'), order:s('Заказ в ERP','ERP order','Comandă ERP'), matched:s('Поля сопоставлены','Fields mapped','Câmpuri mapate'), linked:s('Записи связаны','Records linked','Înregistrări conectate'),
      overview:s('Контроль процесса','Process overview','Monitorizarea procesului'), current:s('Сейчас на согласовании','Currently awaiting approval','În curs de aprobare'), timeline:[s('Заявка создана','Request created','Cerere creată'),s('Бюджет проверен','Budget checked','Buget verificat'),s('Решение руководителя','Manager decision','Decizia managerului')],
      crm:s('Рабочее пространство','Workspace','Spațiu de lucru'), pipeline:s('От сделки до исполнения','From deal to delivery','De la tranzacție la execuție'), deal:s('Сделка','Deal','Tranzacție'), status:s('Этап','Stage','Etapă'), responsible:s('Команда','Team','Echipă'), items:[s('Оснащение нового офиса','New office equipment','Echiparea noului birou'),s('Поставка оборудования','Equipment delivery','Livrare de echipamente'),s('Обслуживание техники','Equipment servicing','Service echipamente')], stages:[s('Согласование','Approval','Aprobare'),s('Заказ в ERP','ERP order','Comandă ERP'),s('Новая заявка','New request','Cerere nouă')], teams:[s('Финансы','Finance','Finanțe'),s('Операции','Operations','Operațiuni'),s('Продажи','Sales','Vânzări')],
      context:s('Единый контекст','Shared context','Context comun'), connected:s('Заявки, решения и данные связаны','Requests, decisions and data are connected','Cereri, decizii și date conectate'),
    },
    allInOne: {
      category:s('Единая платформа','One platform','Platformă unică'), name:'All-in-one CRM',
      title:s('Все процессы. Одно рабочее пространство.','Every process. One workspace.','Toate procesele. Un singur spațiu.'),
      description:s('CRM связывает клиентов и сделки с заявками, бюджетом, согласованиями, ERP и аналитикой. Вместо отдельных островков — общий контекст для всей команды.','CRM connects customers and deals with requests, budget, approvals, ERP and analytics. A shared context for the whole team.','CRM conectează clienții și tranzacțiile cu cererile, bugetul, aprobările, ERP și analiza. Context comun pentru întreaga echipă.'),
      action:s('Посмотреть CRM-сценарий','Explore the CRM scenario','Vezi scenariul CRM'),
      tags:[s('Клиенты и сделки','Customers and deals','Clienți și tranzacții'),s('Команда и документы','Team and documents','Echipă și documente'),s('Операции и аналитика','Operations and analytics','Operațiuni și analiză')],
    },
    note:s('Интерфейсы показывают демонстрационные данные и логику процессов.','Interfaces show demonstration data and process logic.','Interfețele prezintă date demonstrative și logica proceselor.'),
  };
}
